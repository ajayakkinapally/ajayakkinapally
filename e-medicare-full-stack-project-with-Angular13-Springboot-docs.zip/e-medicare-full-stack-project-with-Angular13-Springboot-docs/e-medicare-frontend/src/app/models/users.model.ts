export interface users{
    userid: number;
    firstname: string;
    lastname: string;
    contact_no:number;
    address: string;
    username:string;
    password: string;
    }