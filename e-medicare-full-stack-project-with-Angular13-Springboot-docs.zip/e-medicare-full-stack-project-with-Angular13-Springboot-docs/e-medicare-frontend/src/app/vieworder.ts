export class Vieworder{
    orderid: number=0;
    userid:number=0;
    totalprice:number=1;
    orderdate:number=0;
    
}