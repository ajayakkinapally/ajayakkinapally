export class Medicine{
    medName: String="";
    description:String="";
    expDate:String="";
    manfDate:String="";
    id:number=0;
    status:String="";
    price:number=0;
    
}
